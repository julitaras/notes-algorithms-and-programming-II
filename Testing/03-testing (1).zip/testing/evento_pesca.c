#include "evento_pesca.h"
#include <stdbool.h>
#include <stdlib.h>

arrecife_t *leer_arrecife(arrecife_t *arrecife, FILE *archivo) {
  return NULL;
}

arrecife_t *crear_arrecife(const char *ruta_archivo) {
    return NULL;
}

acuario_t *crear_acuario() {
  acuario_t* un_acuario = calloc(1,sizeof(acuario_t));
  return un_acuario;
}

bool acuario_agregar_pokemon(acuario_t* acuario, pokemon_t* pokemon, int cantidad){
  return false;
}

int trasladar_pokemon(arrecife_t *arrecife, acuario_t *acuario, bool (*seleccionar_pokemon)(pokemon_t *), int cant_seleccion) {
  return 0;
}

void censar_arrecife(arrecife_t* arrecife, void (*mostrar_pokemon)(pokemon_t*)){
}

bool guardar_un_pokemon(FILE *archivo, pokemon_t *un_pokemon) {
  return false;
}

int guardar_datos_acuario(acuario_t *acuario, const char *nombre_archivo) {
  return 0;
}

void liberar_acuario(acuario_t *acuario) {
  free(acuario);
}

void liberar_arrecife(arrecife_t *arrecife) {
  if(!arrecife) return;
  free(arrecife->pokemon);
  free(arrecife);
}
