/*
 * TDA Lapicera
 * Se pide crear el TDA Lapicera que permita 
 * usarla para escribir.
 * La lapicera tiene un color y un limite de letras
 * hasta que se gasta.
 */

#ifndef __LAPICERA_H__
#define __LAPICERA_H__

#include <stdbool.h>

typedef struct lapicera lapicera_t;

/*
 * Crea la estructura lapicera reservando la memoria necesaria.
 * Devolverá la lapicera creada o NULL si no pudo crear.
 */
lapicera_t* lapicera_crear(char color, int letras, bool mordida, bool tiene_tapita);

/*
 * Usará la lapicera restándole la cantidad de tinta que se
 * quieren escribir.
 * Devolverá 0 si la cantidad de tinta alcanzo para escribir
 * o -1 si no.
 */
int lapicera_usar(lapicera_t* lapicera, int letras);

int lapicera_morder(lapicera_t* lapicera);

int lapicera_perder_tapita(lapicera_t* lapicera);

int lapicera_encontrar_tapita(lapicera_t* lapicera);

/*
 * Destruirá la lapicera.
 */
void lapicera_destruir(lapicera_t* lapicera);

#endif /* __LAPICERA_H__ */