#include "lapicera.h"

struct lapicera {
	int color;
	int tinta;
	bool tiene_tapita;
	bool esta_mordida;
};

lapicera_t* lapicera_crear(char color, int letras, bool mordida, bool tiene_tapita) {
	
	lapicera_t* lapi = malloc(sizeof(lapicera_t));
	if(!lapi){
		return NULL;
	}

	lapi->color = color;
	lapi->tinta = letras;
	lapi->tiene_tapita = tiene_tapita;
	lapi->esta_mordida = mordida;

	return lapi;
}

int lapicera_usar(lapicera_t* lapicera, int letras) {

	if (!lapicera)
		return -1;

	if (letras <= 0)
		return -1;

	int retorno = 0;
	lapicera->tinta -= letras;
	if (lapicera->tinta < 0) {
		lapicera->tinta = 0;
		retorno = -1;
	}

	return retorno;
}

int lapicera_morder(lapicera_t* lapicera) {
	if (!lapicera)
		return -1;

	lapicera->esta_mordida = true;
	return 0;
}

int lapicera_perder_tapita(lapicera_t* lapicera) {
	if (!lapicera)
		return -1;

	lapicera->tiene_tapita = false;
	return 0;
}

int lapicera_encontrar_tapita(lapicera_t* lapicera) {
	if (!lapicera)
		return -1;

	lapicera->tiene_tapita = true;
	return 0;
}

void lapicera_destruir(lapicera_t* lapicera) {
	free(lapicera);
}