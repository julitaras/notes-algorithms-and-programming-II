#include "cartuchera.h"

#define MIN_CAPACIDAD 4

cartuchera_t* cartuchera_crear() {
	cartuchera_t* cartu = malloc(sizeof(cartuchera_t));
	if (!cartu)
		return NULL;

	cartu->cantidad = 0;
	cartu->capacidad = MIN_CAPACIDAD;

	cartu->lapiceras = calloc(MIN_CAPACIDAD, sizeof(lapicera_t));
	if (!(cartu->lapiceras)){
		free(cartu);
		return NULL;
	}

	return cartu;
}

void* cartuchera_sacar(cartuchera_t* cartuchera, int posicion) {
	
	if (!cartuchera)
		return NULL;

	if (!cartuchera->cosas)
		return NULL;

	if (posicion < 0 || posicion >= cartuchera->cantidad)
		return NULL;

	void* cosa = cartuchera->cosas[posicion];

	cartuchera->cosas[posicion] = NULL;

	return cosa;
}

int cartuchera_guardar(cartuchera_t* cartuchera, int posicion, lapicera_t* lapicera) {
	
	if (!cartuchera)
		return -1;

	if (!cartuchera->lapiceras)
		return -1;

	if (posicion >= cartuchera->cantidad)
		return -1;

	if (!lapicera)
		return -1;

	if (posicion < 0){
		if (cartuchera->capacidad*0.75 < cartuchera->cantidad){
			lapicera_t* lapiceras = realloc(cartuchera->lapiceras, cartuchera->capacidad*2);
			if (!lapiceras)
				return -1;

			cartuchera->capacidad *= 2;
			cartuchera->lapiceras = lapiceras;
			posicion = cartuchera->cantidad;
			(cartuchera->cantidad)++;
		}
	}

	cartuchera->lapiceras[posicion] = lapicera;
	return 0;

}

void cartuchera_destruir(cartuchera_t* cartuchera, 
						
						) {

}
