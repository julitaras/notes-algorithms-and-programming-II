/*
 * TDA Cartuchera
 * Se pide crear el TDA Cartuchera que permita 
 * almacenar lapiceras, sacarlas para usar y luego
 * volverlas a guardar.
 * La cartuchera es elástica, por lo que 
 * crecerá si su capacidad supera el 75%.
 */

#ifndef __CARTUCHERA_H__
#define __CARTUCHERA_H__

#include "lapicera.h"

typedef struct cartuchera {
	lapicera_t** lapiceras;
	int cantidad_lapiceras;
	int capacidad; 
} cartuchera_t;

/*
 * Crea la estructura cartuchera reservando la memoria necesaria.
 * La cartuchera se crea vacía y con lugar para 10 lapiceras.
 * Devolverá la cartuchera creada o NULL si no pudo crear.
 */
cartuchera_t* cartuchera_crear();

/*
 * Devolverá la lapicera ubicada en la posición solicitada.
 * Si la lapicera no existe, devolverá NULL.
 */
lapicera_t* cartuchera_sacar(cartuchera_t* cartuchera, int posicion);

/*
 * Guardará una lapicera en la posición indicada.
 * Si la posición es -1, es un lapicera nueva, debe ser ubicada al final.
 */
int cartuchera_guardar(cartuchera_t* cartuchera, int posicion, lapiceta_t* lapicera);

/*
 * Destruirá la cartuchera y su contenido.
 */
void cartuchera_destruir(cartuchera_t* cartuchera);

#endif /* __CARTUCHERA_H__ */