#include <stdio.h>
#include "cartuchera.h"
#include "lapicera.h"

int main(){
	cartuchera_t* cartu = cartuchera_crear();
	lapicera_t* lapicera;

	lapicera = lapicera_crear('A', 50,);
	cartuchera_guardar(cartu, lapicera, 0);

	sacapunta_t* saca;
	saca = sacapunta_crear();
	cartuchera_guardar(cartu, saca, 1);

	lucas_t* lucas;
	lucas = lucas_crear();
	cartuchera_guardar(cartu, lucas, 2);

	lapicera_t* lapicera = (lapicera_t*) cartuchera_sacar(cartuchera, 0);
	sacapunta_t* sacap = (sacapunta_t*) cartuchera_sacar(cartuchera, 1);

	return 0;
}