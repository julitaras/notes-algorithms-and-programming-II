/*
 * Diagrame cómo queda el Stack y el Heap al 
 * finalizar la ejecución.
 */

int main(){
	int a;
	int* p_numero = &a;
	*p_numero = 8;
}